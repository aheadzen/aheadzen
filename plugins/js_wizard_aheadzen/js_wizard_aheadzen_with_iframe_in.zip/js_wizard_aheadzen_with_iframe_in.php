<?php
/**
 * Plugin Name: JS Wizard for Singup IFRAME Aheadzen
 * Plugin URI: http://aheadzen.com
 * Text Domain: fli
 * Domain Path: /lang
 * Description: register form shortcode :: [aheadzen_registerform]
 * Author: r Krishana
 * Author URI: http://aheadzen.com
 * Version: 1.0.0
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */
session_start();
ob_start();
$plugin_dir_path = dirname(__FILE__);
$plugin_dir_url = plugins_url('', __FILE__);

add_action('init','signup_wizard_init');
function signup_wizard_init()
{
	add_filter('show_admin_bar', '__return_false');
}

add_action('wp_head','wp_head_singup_wizard');
function wp_head_singup_wizard()
{
?>
	<style>
	#privacy {display:none;}
	</style>
<?php
}
//add_action('signup_header','signup_header_fun');
function signup_header_fun11()
{
global $plugin_dir_url;
?>
<style>
.privacy-intro,#signupblog,#signupuser,.mu_register label.checkbox{display:none !important;}
.site-main .widecolumn{padding-top:50px;}
.steps ul{ list-style: none outside none;}
.steps ul li {background-color: #ccc; border: 1px solid #ccc; float: left; margin: 5px 3px; padding: 5px 8px;}
.steps ul li.current{background-color: #fff;}
</style>
<?php
}

//add_action('before_signup_form','after_signup_form_fun');
function after_signup_form_fun11()
{
?>
<div class="mu_register" style="margin-top:50px; margin-bottom:0;">
<?php
if($_POST['stage']=='validate-user-signup')
{
	$step2='current';
}else{
	$step1='current';
}
?>
 <div class="steps clearfix">
	<ul role="tablist">
		<li role="tab" class="first <?php echo $step1;?>" aria-disabled="false" aria-selected="true">
			<a aria-controls="wizard-p-0" href="#wizard-h-0" id="wizard-t-0">
			<span class="number">1.</span> First Step</a>
		</li>
		<li role="tab" class="disabled <?php echo $step2;?>" aria-disabled="true">
			<a aria-controls="wizard-p-1" href="#wizard-h-1" id="wizard-t-1">
			<span class="number">2.</span> Second Step</a>
		</li>
		<li role="tab" class="disabled <?php echo $step3;?>" aria-disabled="true">
			<a aria-controls="wizard-p-2" href="#wizard-h-2" id="wizard-t-2">
			<span class="number">3.</span> Third Step</a>
		</li>
		<li role="tab" class="disabled <?php echo $step4;?>" aria-disabled="true">
			<a aria-controls="wizard-p-3" href="#wizard-h-3" id="wizard-t-3">
			<span class="number">4.</span> Forth Step</a>
		</li>
		</ul>
	</div>
</div>
<?php
}

add_action('signup_finished','signup_finished_funcode_plugin');
function signup_finished_funcode_plugin()
{	
global $wpdb, $blogname, $blog_title, $errors, $domain, $path;
	$slug = 'bazar-child';
	$encoded_slug = urlencode( $slug );
	$activeurl = str_replace('&amp;','&',(wp_nonce_url( 'http://'.$domain.$path. 'wp-admin/themes.php?action=activate&stylesheet='.$encoded_slug , 'switch-theme_' . $slug )));
	

?>
	<!-- <script>window.location.href="<?php echo $activeurl;?>";</script>-->
	<iframe style="border:1px solid red;height:500px; width:100%;" scr="<?php echo $activeurl;?>" id="form_submit_iframe" name="form_submit_iframe"></iframe>
<?php
	exit;
}

add_filter('template_include','wpw_template_include');
function wpw_template_include($template)
{
	if($_POST['registernewuser'])
	{
		
		$user_login = '';
		$user_email = '';
		if ( !get_option('users_can_register') ) {
			wp_redirect(site_url().'?ptype=login&page1=sign_up&emsg=regnewusr');
			exit();
		}		
		
		if ( $_POST ) {
			$user_login = $_POST['user_login'];
			$user_email = $_POST['user_email'];
			$password = $_POST['password'];
			$repeat_password = $_POST['repeat_password'];
			
			$errors = new WP_Error();
			
			$errors = register_new_user($user_login, $user_email);
			
			if ( $_POST['password'] !== $_POST['repeat_password'] ) {
			$errors->add( 'passwords_not_matched', "<strong>ERROR</strong>: Passwords must match" );
			}
			
			if ( strlen( $_POST['password'] ) < 8 ) {
				$errors->add( 'password_too_short', "<strong>ERROR</strong>: Passwords must be at least eight characters long" );
			}

			if ( !is_wp_error($errors) ) 
			{
				$_POST['log'] = $user_login;
				$_POST['pwd'] = $password;
				$_POST['testcookie'] = 1;
				
				$secure_cookie = '';
				// If the user wants ssl but the session is not ssl, force a secure cookie.
				if ( !empty($_POST['log']) && !force_ssl_admin() )
				{
					$user_name = sanitize_user($_POST['log']);
					if ( $user = get_userdatabylogin($user_name) )
					{
							wp_set_auth_cookie( $user->ID, false, is_ssl() );
							wp_redirect($_REQUEST['redirect_to'] );exit;
					}
				}
			}
			$_SESSION['emsg_array']=$errors;
		}
	}
	return apply_filters('wpw_add_template_page_filter',$template);
}


/****************************
//WordPress register  Form Short Code
[aheadzen_registerform]
*****************************/
if(!function_exists('aheadzen_register_form_shortcode'))
{
	function aheadzen_register_form_shortcode( $atts, $content = null ) {
	 
		extract( shortcode_atts( array(
		  'redirect' => site_url().'/wp-signup.php'
		  ), $atts ) );
		  
		 $redirect_to = site_url().'/wp-signup.php';
		global $current_user;
		ob_start();
		if (!is_user_logged_in()) {
			
			if($_SESSION['emsg_array'])
			{
				$emsg_array = $_SESSION['emsg_array'];
				echo '<div class="errormsg">'.implode('<br>',$emsg_array).'</div>';
				$_SESSION['emsg_array'] = array();
			}
			?>
			<form name="registerform" id="registerform" action="" method="post">
			<input type="hidden" name="registernewuser" value="1" />
			<p>
					<label for="user_login"><?php _e('Username') ?><br />
					<input type="text" name="user_login" id="user_login" class="input" value="<?php echo esc_attr(wp_unslash($user_login)); ?>" size="20" /></label>
				</p>
				<p>
					<label for="user_email"><?php _e('E-mail') ?><br />
					<input type="text" name="user_email" id="user_email" class="input" value="<?php echo esc_attr(wp_unslash($user_email)); ?>" size="25" /></label>
				</p>
				
				<p>
					<label for="password">Password<br/>
					<input id="password" class="input" type="password" size="25" value="" name="password" />
				</label>
				</p>
				<p>
					<label for="repeat_password">Repeat password<br/>
					<input id="repeat_password" class="input" type="password" size="25" value="" name="repeat_password" />
				</label>
				</p>
				<?php
				/**
				 * Fires following the 'E-mail' field in the user registration form.
				 *
				 * @since 2.1.0
				 */
				do_action( 'register_form' );
				?>
				<br class="clear" />
				<input type="hidden" name="redirect_to" value="<?php echo esc_attr( $redirect_to ); ?>" />
				<p class="submit"><input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="<?php esc_attr_e('Register'); ?>" /></p>
			</form>
			<?php		
		}else{?>		
		<h2>You are already loged in.</h2>
		<h3>
		Please click the link to create new site >>  <a href="<?php echo site_url('wp-signup.php'); ?>"><?php _e('Create New Site','woothemes'); ?></a>
		</h3>

		<h3>
		Please logout by click >>  
		<a href="<?php echo wp_logout_url(); ?>"><?php _e('Logout','woothemes'); ?></a>
		</h3>		
			<?php
		}
		
		$form = ob_get_contents();
		ob_end_clean();		
		return $form;
	}
	add_shortcode('aheadzen_registerform', 'aheadzen_register_form_shortcode');
}

 